package ucsal.br;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class DeleteSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_selection);
    }
}